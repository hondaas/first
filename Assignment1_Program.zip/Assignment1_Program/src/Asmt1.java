
public class Asmt1 {

	public static void main(String[] args) {

		System.out.println("dfg");
		System.out.println();
		System.out.print("/n");
		
		
		String b = "%";

		for (int i = 0; i < 5; ++i) {

			System.out.println(b);

			b = b + "%";
		}
		
		
		
		// 다른 사람 꺼
		
			for (int j = 1; j < 6; j++) {

				for (int k = 0; k < j; k++) {

					System.out.print("%");

				}
				System.out.println(" ");
			}

		

	}

}
